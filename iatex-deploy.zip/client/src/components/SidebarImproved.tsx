import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { 
  Brain,
  Gauge,
  TrendingUp,
  Scissors,
  Calculator,
  BarChart3,
  FileText,
  ShoppingCart,
  Factory,
  FolderOpen,
  PieChart,
  Calendar,
  QrCode,
  CheckSquare,
  UserCheck,
  Bot,
  Building,
  Users,
  Package,
  Shield,
  Download,
  Bell,
  Settings,
  Star,
  StarOff
} from "lucide-react";
import { ActiveSection } from "../pages/Home";
import { useAuth } from "../hooks/useAuth";

interface SidebarProps {
  activeSection: ActiveSection;
  onSectionChange: (section: ActiveSection) => void;
}

export default function SidebarImproved({ activeSection, onSectionChange }: SidebarProps) {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<string[]>([]);

  // Carregar favoritos do localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('ia-tex-favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Salvar favoritos no localStorage
  const saveFavorites = (newFavorites: string[]) => {
    setFavorites(newFavorites);
    localStorage.setItem('ia-tex-favorites', JSON.stringify(newFavorites));
  };

  // Toggle favorito
  const toggleFavorite = (moduleId: string) => {
    const newFavorites = favorites.includes(moduleId)
      ? favorites.filter(id => id !== moduleId)
      : [...favorites, moduleId];
    saveFavorites(newFavorites);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Lista completa de todos os módulos
  const allModules = [
    // Principais
    { id: 'dashboard', icon: Gauge, label: 'Dashboard', badge: null, section: 'main' },
    { id: 'financial', icon: TrendingUp, label: 'Financeiro', badge: null, section: 'main' },
    
    // Produção & Materiais
    { id: 'fabrics', icon: Scissors, label: 'Tecidos', badge: 3, section: 'production' },
    { id: 'models', icon: Calculator, label: 'Modelos & Precificação', badge: null, section: 'production' },
    { id: 'simulations', icon: BarChart3, label: 'Simulações Avançadas', badge: null, section: 'production' },
    { id: 'quotations', icon: FileText, label: 'Orçamentos', badge: null, section: 'production' },
    { id: 'orders', icon: ShoppingCart, label: 'Pedidos', badge: 12, section: 'production' },
    { id: 'production-advanced', icon: Factory, label: 'Produção Avançada', badge: null, section: 'production' },
    { id: 'inventory', icon: Package, label: 'Estoque Inteligente', badge: null, section: 'production' },
    
    // Ferramentas & Relatórios
    { id: 'documents', icon: FolderOpen, label: 'Central de Documentos', badge: null, section: 'tools' },
    { id: 'reports', icon: PieChart, label: 'Relatórios Inteligentes', badge: null, section: 'tools' },
    { id: 'calendar', icon: Calendar, label: 'Calendário de Produção', badge: null, section: 'tools' },
    { id: 'qr-generator', icon: QrCode, label: 'QR Code & Etiquetas', badge: null, section: 'tools' },
    
    // Painéis
    { id: 'operational-panel', icon: CheckSquare, label: 'Painel Operacional', badge: null, section: 'panels' },
    { id: 'employee-management', icon: UserCheck, label: 'Gestão de Funcionários', badge: null, section: 'panels' },
    { id: 'user-panels', icon: Users, label: 'Painéis de Usuário', badge: null, section: 'panels' },
    { id: 'ai-assistant', icon: Bot, label: 'Assistente IA', badge: null, section: 'panels' },
    
    // Gestão
    { id: 'clients', icon: Building, label: 'Gestão de Clientes', badge: null, section: 'management' },
    { id: 'administration', icon: Shield, label: 'Administração', badge: null, section: 'management' },
    { id: 'backup', icon: Download, label: 'Backup & Exportação', badge: null, section: 'management' },
    { id: 'notifications', icon: Bell, label: 'Central de Notificações', badge: null, section: 'management' },
    
    // Configurações
    { id: 'brand-settings', icon: Settings, label: 'Configurações da Marca', badge: null, section: 'settings' },
  ];

  // Módulos agrupados por seção para exibição
  const mainModules = allModules.filter(m => m.section === 'main');
  const productionModules = allModules.filter(m => m.section === 'production');
  const toolsModules = allModules.filter(m => m.section === 'tools');
  const panelsModules = allModules.filter(m => m.section === 'panels');
  const managementModules = allModules.filter(m => m.section === 'management');
  const settingsModules = allModules.filter(m => m.section === 'settings');

  // Módulos favoritos
  const favoriteModules = allModules.filter(module => favorites.includes(module.id));

  // Componente para renderizar item do menu
  const renderMenuItem = (item: any, showFavoriteButton = false) => {
    const IconComponent = item.icon;
    const isFavorite = favorites.includes(item.id);
    
    return (
      <div key={item.id} className="group relative">
        <button
          onClick={() => onSectionChange(item.id)}
          className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors ${
            activeSection === item.id
              ? 'bg-blue-100 text-blue-900'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <div className="flex items-center gap-3">
            <IconComponent className="h-4 w-4" />
            <span>{item.label}</span>
          </div>
          <div className="flex items-center gap-2">
            {item.badge && (
              <Badge variant={typeof item.badge === 'number' ? 'destructive' : 'secondary'} className="text-xs">
                {item.badge}
              </Badge>
            )}
            {showFavoriteButton && (
              <div
                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer hover:bg-gray-100 rounded flex items-center justify-center"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(item.id);
                }}
              >
                {isFavorite ? (
                  <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                ) : (
                  <StarOff className="h-3 w-3" />
                )}
              </div>
            )}
          </div>
        </button>
      </div>
    );
  };

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg">IA.TEX</span>
        </div>
        {user && (
          <p className="text-xs text-gray-500 mt-2 truncate">
            {user.email}
          </p>
        )}
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
        
        {/* Módulos Favoritos */}
        {favoriteModules.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
              ⭐ Favoritos
            </h3>
            <div className="space-y-1">
              {favoriteModules.map(item => renderMenuItem(item, true))}
            </div>
          </div>
        )}

        {/* Principais */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Principais
          </h3>
          <div className="space-y-1">
            {mainModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>

        {/* Produção & Materiais */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Produção & Materiais
          </h3>
          <div className="space-y-1">
            {productionModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>

        {/* Ferramentas & Relatórios */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Ferramentas & Relatórios
          </h3>
          <div className="space-y-1">
            {toolsModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>

        {/* Painéis */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Painéis
          </h3>
          <div className="space-y-1">
            {panelsModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>

        {/* Gestão */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Gestão
          </h3>
          <div className="space-y-1">
            {managementModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>

        {/* Configurações */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Configurações
          </h3>
          <div className="space-y-1">
            {settingsModules.map(item => renderMenuItem(item, true))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t">
        <Button 
          onClick={handleLogout}
          variant="outline" 
          size="sm" 
          className="w-full"
        >
          Sair
        </Button>
      </div>
    </div>
  );
}